import pandas as pd
from src.model import WeatherModel

def test_model_training_and_prediction():
    X = pd.DataFrame({
        "Humidity": [50, 60, 70, 80],
        "Pressure": [1010, 1011, 1012, 1013],
        "WindSpeed": [5, 6, 7, 8],
        "Rainfall": [0, 1, 2, 3]
    })
    y = pd.Series([25, 26, 27, 28])
    model = WeatherModel()
    X_train, X_test, y_train, y_test = model.split_data(X, y)
    model.train(X_train, y_train)
    pred = model.predict(X_test)
    assert len(pred) == len(y_test)
    assert all(pred > 0)
