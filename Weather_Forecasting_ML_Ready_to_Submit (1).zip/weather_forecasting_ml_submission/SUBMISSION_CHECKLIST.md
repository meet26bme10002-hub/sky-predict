# Ready-to-Submit Checklist

## Before submission
- [ ] Replace `Your Name`, `Your Roll Number`, `Your Course Name`, `Your College Name`.
- [ ] Confirm whether your instructor requires a real public weather dataset. If yes, replace `data/weather.csv` and rerun the project.
- [ ] Run `pip install -r requirements.txt`.
- [ ] Run `pytest`.
- [ ] Run `python src/main.py`.
- [ ] Review all plots and metrics.
- [ ] If screenshots are required, add them to the report.
- [ ] Review report formatting and college citation requirements.
- [ ] Create your GitHub repository and push the project.
- [ ] Submit the ZIP/PDF/PPT according to your college instructions.

## Included
- Complete source code
- Dataset
- Generated outputs
- Diagrams
- DOCX and Markdown report
- PPTX presentation
- Viva questions/answers
- README, statement, requirements, license, .gitignore
- Git guide
