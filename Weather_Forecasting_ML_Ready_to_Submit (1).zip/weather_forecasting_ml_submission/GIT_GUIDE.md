# Git/GitHub Submission Guide

```bash
git init
git add .
git commit -m "Initial weather forecasting project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

For later changes:
```bash
git add .
git commit -m "Updated model and documentation"
git push
```
