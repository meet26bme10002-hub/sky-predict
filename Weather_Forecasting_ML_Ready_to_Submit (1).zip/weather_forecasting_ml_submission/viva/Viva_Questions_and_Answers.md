# Viva Questions and Answers

## 1. What is machine learning?
Machine learning is a computational approach in which a model learns patterns from data and uses those patterns to make predictions or decisions.

## 2. What type of machine learning is used?
Supervised learning, because the training data contains input features and a known target temperature.

## 3. What type of problem is this?
Regression, because temperature is a continuous numerical value.

## 4. Which algorithm is used?
Linear Regression.

## 5. Why Linear Regression?
It is simple to understand, fast to train, suitable for numerical prediction, and easy to explain in a beginner project.

## 6. What is the target variable?
Temperature.

## 7. What are the input features?
Humidity, Pressure, WindSpeed, and Rainfall.

## 8. Why split the dataset?
Training data is used to learn the model parameters; testing data is used to measure performance on unseen rows.

## 9. What is the split ratio?
80% training and 20% testing.

## 10. What is MAE?
Mean Absolute Error is the average absolute difference between actual and predicted values.

## 11. What is MSE?
Mean Squared Error is the average of squared prediction errors.

## 12. What is RMSE?
Root Mean Squared Error is the square root of MSE and expresses error in the target's units.

## 13. What is R²?
R² measures the proportion of variation in the target that is explained by the regression model.

## 14. What is Pandas used for?
Reading, cleaning, transforming, and analyzing tabular weather data.

## 15. What is NumPy used for?
Numerical operations, including calculation of RMSE in this project.

## 16. What is Matplotlib used for?
Creating visualizations such as temperature, humidity, and actual-versus-predicted plots.

## 17. What is Scikit-learn used for?
Linear Regression, train/test splitting, and evaluation metrics.

## 18. Why use CSV instead of a database?
CSV is lightweight, easy to understand, and sufficient for this educational application.

## 19. What happens if a required CSV column is missing?
The data processor raises a clear validation error identifying the missing column.

## 20. What happens if the user enters text instead of a number?
The main program catches ValueError and displays an input error message.

## 21. Is this a professional weather forecasting system?
No. It is an educational machine-learning demonstration.

## 22. Is the included dataset real?
No. The included dataset is explicitly synthetic and is provided for reproducible educational execution. If the college requires real observations, replace it with a documented public dataset.

## 23. What is overfitting?
Overfitting occurs when a model learns training-specific patterns too closely and performs poorly on unseen data.

## 24. Why is a test set important?
It gives an estimate of how the trained model behaves on data it did not use during fitting.

## 25. What is modular programming?
Dividing a program into separate components with focused responsibilities. Here, processing, modeling, visualization, prediction, and orchestration are separated.

## 26. Why use random_state=42?
It makes the train/test split reproducible so the same code produces the same split.

## 27. What would you improve in a future version?
Use a documented real weather dataset, compare several algorithms, add time-series features, support real-time APIs, and build a graphical or web interface.

## 28. How would you explain the project in one minute?
The system loads historical weather data, cleans it, selects humidity, pressure, wind speed and rainfall as features, trains a Linear Regression model to estimate temperature, evaluates the model with MAE/MSE/RMSE/R², creates graphs, and finally accepts new weather values to estimate temperature.

## Quick formula sheet
Linear Regression:
`y = b0 + b1x1 + b2x2 + ... + bnxn`

MAE:
`average(|actual - predicted|)`

MSE:
`average((actual - predicted)^2)`

RMSE:
`sqrt(MSE)`

R²:
`1 - (sum of squared residuals / total sum of squares)`


## Project-specific result values
Using the included dataset and current code: MAE = 0.7012, MSE = 0.7684, RMSE = 0.8766, R² = 0.7390.
