import pandas as pd

class Predictor:
    def __init__(self, model):
        self.model = model

    def predict_temperature(self, humidity, pressure, wind_speed, rainfall):
        row = pd.DataFrame([{
            "Humidity": humidity,
            "Pressure": pressure,
            "WindSpeed": wind_speed,
            "Rainfall": rainfall
        }])
        return float(self.model.predict(row)[0])
