from pathlib import Path
import matplotlib.pyplot as plt

class Visualizer:
    def __init__(self, output_dir="outputs"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def plot_temperature(self, data):
        plt.figure(figsize=(10, 5))
        plt.plot(data["Date"], data["Temperature"], linewidth=1)
        plt.title("Temperature Over Time")
        plt.xlabel("Date"); plt.ylabel("Temperature (°C)")
        plt.xticks(rotation=30); plt.tight_layout()
        plt.savefig(self.output_dir/"temperature_plot.png", dpi=160); plt.close()

    def plot_humidity(self, data):
        plt.figure(figsize=(10, 5))
        plt.plot(data["Date"], data["Humidity"], linewidth=1)
        plt.title("Humidity Over Time")
        plt.xlabel("Date"); plt.ylabel("Humidity (%)")
        plt.xticks(rotation=30); plt.tight_layout()
        plt.savefig(self.output_dir/"humidity_plot.png", dpi=160); plt.close()

    def plot_actual_vs_predicted(self, actual, predicted):
        plt.figure(figsize=(7, 6))
        plt.scatter(actual, predicted, alpha=0.65)
        lo, hi = min(actual.min(), predicted.min()), max(actual.max(), predicted.max())
        plt.plot([lo, hi], [lo, hi], linestyle="--")
        plt.xlabel("Actual Temperature (°C)")
        plt.ylabel("Predicted Temperature (°C)")
        plt.title("Actual vs Predicted Temperature")
        plt.tight_layout()
        plt.savefig(self.output_dir/"actual_vs_predicted.png", dpi=160); plt.close()
