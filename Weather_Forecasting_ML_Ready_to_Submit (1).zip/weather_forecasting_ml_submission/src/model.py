import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

class WeatherModel:
    def __init__(self):
        self.model = LinearRegression()

    def split_data(self, X, y):
        return train_test_split(X, y, test_size=0.20, random_state=42)

    def train(self, X_train, y_train):
        self.model.fit(X_train, y_train)

    def predict(self, X):
        return self.model.predict(X)

    def evaluate(self, y_true, predictions):
        mse = mean_squared_error(y_true, predictions)
        return {
            "MAE": mean_absolute_error(y_true, predictions),
            "MSE": mse,
            "RMSE": np.sqrt(mse),
            "R2": r2_score(y_true, predictions)
        }
