from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.data_processor import DataProcessor
from src.model import WeatherModel
from src.visualizer import Visualizer
from src.predictor import Predictor

def main():
    print("="*55)
    print("        WEATHER FORECASTING USING MACHINE LEARNING")
    print("="*55)

    processor = DataProcessor(ROOT / "data" / "weather.csv")
    data = processor.load_data()
    if data is None:
        return
    data = processor.clean_data(data)
    print(f"\nDataset loaded successfully: {len(data)} rows")
    print(data.head())

    X, y = processor.prepare_data(data)
    weather_model = WeatherModel()
    X_train, X_test, y_train, y_test = weather_model.split_data(X, y)
    weather_model.train(X_train, y_train)

    predictions = weather_model.predict(X_test)
    metrics = weather_model.evaluate(y_test, predictions)
    print("\nMODEL EVALUATION")
    print("-"*30)
    for k, v in metrics.items():
        print(f"{k:5}: {v:.4f}")

    out = ROOT / "outputs"
    out.mkdir(exist_ok=True)
    pd.DataFrame({
        "ActualTemperature": y_test.to_numpy(),
        "PredictedTemperature": predictions,
        "PredictionError": y_test.to_numpy() - predictions
    }).to_csv(out/"prediction_results.csv", index=False)
    pd.DataFrame([metrics]).to_csv(out/"metrics.csv", index=False)

    viz = Visualizer(out)
    viz.plot_temperature(data)
    viz.plot_humidity(data)
    viz.plot_actual_vs_predicted(y_test.reset_index(drop=True), pd.Series(predictions))

    print("\nEnter weather information for a new prediction.")
    try:
        humidity = float(input("Humidity (%): "))
        pressure = float(input("Pressure (hPa): "))
        wind_speed = float(input("Wind Speed (km/h): "))
        rainfall = float(input("Rainfall (mm): "))
        result = Predictor(weather_model.model).predict_temperature(
            humidity, pressure, wind_speed, rainfall
        )
        print(f"\nPredicted Temperature: {result:.2f} °C")
    except ValueError:
        print("Invalid input. Please enter numerical values.")

if __name__ == "__main__":
    main()
