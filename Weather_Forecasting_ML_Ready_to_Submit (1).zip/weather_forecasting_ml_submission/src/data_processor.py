import pandas as pd

class DataProcessor:
    REQUIRED_COLUMNS = ["Temperature", "Humidity", "Pressure", "WindSpeed", "Rainfall"]

    def __init__(self, file_path):
        self.file_path = file_path

    def load_data(self):
        try:
            return pd.read_csv(self.file_path)
        except FileNotFoundError:
            print(f"Error: Dataset not found: {self.file_path}")
            return None

    def clean_data(self, data):
        if data is None:
            return None
        missing = [c for c in self.REQUIRED_COLUMNS if c not in data.columns]
        if missing:
            raise ValueError(f"Required column(s) missing: {', '.join(missing)}")
        data = data.copy()
        if "Date" in data.columns:
            data["Date"] = pd.to_datetime(data["Date"], errors="coerce")
        for col in self.REQUIRED_COLUMNS:
            data[col] = pd.to_numeric(data[col], errors="coerce")
        data = data.dropna(subset=self.REQUIRED_COLUMNS).reset_index(drop=True)
        return data

    def prepare_data(self, data):
        features = ["Humidity", "Pressure", "WindSpeed", "Rainfall"]
        return data[features], data["Temperature"]
